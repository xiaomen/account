===================================
cssselect: CSS Selectors for Python
===================================

*cssselect* parses `CSS3 Selectors`_ and translate them to `XPath 1.0`_
expressions. Such expressions can be used in lxml_ or another XPath engine
to find the matching elements in an XML or HTML document.

This module used to live inside of lxml as ``lxml.cssselect`` before it was
extracted as a stand-alone project.

.. _CSS3 Selectors: http://www.w3.org/TR/2011/REC-css3-selectors-20110929/
.. _XPath 1.0: http://www.w3.org/TR/xpath/
.. _lxml: http://lxml.de/


Quick facts:

* Free software: BSD licensed
* Compatible with Python 2.4+ and 3.x
* Latest documentation `on python.org <http://packages.python.org/cssselect/>`_
* Source, issues and pull requests `on Github
  <https://github.com/SimonSapin/cssselect/>`_
* Releases `on PyPI <http://pypi.python.org/pypi/cssselect>`_
* Install with ``pip install cssselect``
