======
Fixers
======

.. automodule:: werkzeug.contrib.fixers

.. autoclass:: LighttpdCGIRootFix

.. autoclass:: PathInfoFromRequestUriFix

.. autoclass:: ProxyFix
   :members:

.. autoclass:: HeaderRewriterFix

.. autoclass:: InternetExplorerFix
